<script>
    function filter(uri) {
        window.location.replace(uri);
    }
</script>
