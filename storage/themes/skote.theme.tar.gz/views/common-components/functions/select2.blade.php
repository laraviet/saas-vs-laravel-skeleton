<script src="{{ theme_url('assets/libs/select2/select2.min.js')}}"></script>
<script>
    $(document).ready(function () {
        $('.select2').select2();
    });
</script>
