<div class="form-group row mb-4">
    <label for=""
           class="col-form-label col-lg-2"></label>
    <div class="col-lg-10">
        <img src="{{ url($path) }}"/>
    </div>
</div>
